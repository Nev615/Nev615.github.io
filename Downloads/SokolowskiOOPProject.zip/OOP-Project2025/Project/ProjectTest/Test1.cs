﻿using OOP_Project;

namespace ProjectTest
{
    [TestClass]
    public sealed class Test1
    {

        LoginPage testForm;

        [TestInitialize]
        public void SetUp()
        {
            testForm = new LoginPage();
        }
        

        [TestMethod]
        public void CheckPassword_Valid()
        {
            //For some reason this is not asserting as true
            //Arrange
            string userName = "cathy";
            string password = "cathy";

            //Act
            bool valid = testForm.CheckPassword(userName, password);

            //Assert
            Assert.IsTrue(valid);
        }

        [TestMethod]
        public void CheckPassword_Invalid()
        {
            //Arrange
            string userName = "cathy";
            string password = "cathy";

            //Act
            bool valid = testForm.CheckPassword("Wrong", "Name");

            //Assert
            Assert.IsFalse(valid);
        }

    }
}
