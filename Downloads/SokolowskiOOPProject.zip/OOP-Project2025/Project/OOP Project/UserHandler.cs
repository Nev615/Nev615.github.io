﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Project
{
    public class UserHandler
    {
        private static string fileName = "userFile.txt";
        private string filePath = "";
        private List<User> users = new List<User>();

        public UserHandler()
        {
            filePath += Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);
            //MessageBox.Show(filePath);
            readFile();
        }
        public void readFile()
        {
            int userID = 0;
            if (File.Exists(filePath))
            {
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    // Create and Store Users
                    string[] properties = line.Split(',');
                    if (properties[0] == "Admin")
                    {
                        Admin admin = new Admin(properties[1], properties[2], userID);
                        userID++;
                        users.Add(admin);
                    }
                    else if (properties[0] == "Customer")
                    {
                        Customer cust = new Customer(properties[1], properties[2], userID);
                        userID++;
                        users.Add(cust);
                    }
                }
            }
            else
            {
                MessageBox.Show("Error UserFile Not Found", "Error");
            }

        }

        public List<User> GetUsers()
        {
            return users;
        }

        public void SaveUsers(List <User> users)
        {
            List<string> lines = new List<string>();
            foreach(User user in users)
            {
                lines.Add(user.ToString());
            }
            using (StreamWriter writer = new StreamWriter(filePath, append: false))
            {
                foreach (string line in lines)
                {
                    writer.WriteLine(line);
                }
            }
        }
    }
}
