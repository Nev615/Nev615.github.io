﻿namespace OOP_Project
{
    partial class ProjectAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProjectAdmin));
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            radCreate = new RadioButton();
            radEdit = new RadioButton();
            pictureBox1 = new PictureBox();
            nudEditQuantity = new NumericUpDown();
            btnEditCancel = new Button();
            btnEditConfirmChanges = new Button();
            txtEditProductDescription = new TextBox();
            label5 = new Label();
            txtEditPrice = new TextBox();
            label4 = new Label();
            label3 = new Label();
            txtEditProductID = new TextBox();
            label2 = new Label();
            txtEditProductName = new TextBox();
            label1 = new Label();
            lstEditProducts = new ListBox();
            tabPage2 = new TabPage();
            pictureBox2 = new PictureBox();
            nudSalary = new NumericUpDown();
            dtpEmployeeStartDate = new DateTimePicker();
            btnCancelEmployee = new Button();
            btnAddEmployee = new Button();
            txtEmployeeEmail = new TextBox();
            label12 = new Label();
            txtEmployeePhoneNumber = new TextBox();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            txtEmployeeAddress = new TextBox();
            label8 = new Label();
            txtEmployeeLastName = new TextBox();
            label7 = new Label();
            txtEmployeeFirstName = new TextBox();
            label6 = new Label();
            lstEmployees = new ListBox();
            fileSystemWatcher1 = new FileSystemWatcher();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudEditQuantity).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudSalary).BeginInit();
            ((System.ComponentModel.ISupportInitialize)fileSystemWatcher1).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(6, 9);
            tabControl1.Margin = new Padding(2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(643, 338);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(radCreate);
            tabPage1.Controls.Add(radEdit);
            tabPage1.Controls.Add(pictureBox1);
            tabPage1.Controls.Add(nudEditQuantity);
            tabPage1.Controls.Add(btnEditCancel);
            tabPage1.Controls.Add(btnEditConfirmChanges);
            tabPage1.Controls.Add(txtEditProductDescription);
            tabPage1.Controls.Add(label5);
            tabPage1.Controls.Add(txtEditPrice);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(txtEditProductID);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(txtEditProductName);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(lstEditProducts);
            tabPage1.Location = new Point(4, 28);
            tabPage1.Margin = new Padding(2);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(2);
            tabPage1.Size = new Size(635, 306);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Product";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // radCreate
            // 
            radCreate.AutoSize = true;
            radCreate.Location = new Point(407, 6);
            radCreate.Name = "radCreate";
            radCreate.Size = new Size(103, 23);
            radCreate.TabIndex = 18;
            radCreate.TabStop = true;
            radCreate.Text = "Create Item";
            radCreate.UseVisualStyleBackColor = true;
            radCreate.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radEdit
            // 
            radEdit.AutoSize = true;
            radEdit.Location = new Point(243, 6);
            radEdit.Name = "radEdit";
            radEdit.Size = new Size(88, 23);
            radEdit.TabIndex = 17;
            radEdit.TabStop = true;
            radEdit.Text = "Edit Item";
            radEdit.UseVisualStyleBackColor = true;
            radEdit.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(567, 2);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(65, 59);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 16;
            pictureBox1.TabStop = false;
            // 
            // nudEditQuantity
            // 
            nudEditQuantity.Location = new Point(315, 108);
            nudEditQuantity.Margin = new Padding(2);
            nudEditQuantity.Name = "nudEditQuantity";
            nudEditQuantity.Size = new Size(311, 27);
            nudEditQuantity.TabIndex = 15;
            // 
            // btnEditCancel
            // 
            btnEditCancel.Location = new Point(452, 258);
            btnEditCancel.Margin = new Padding(2);
            btnEditCancel.Name = "btnEditCancel";
            btnEditCancel.Size = new Size(174, 40);
            btnEditCancel.TabIndex = 14;
            btnEditCancel.Text = "Cancel";
            btnEditCancel.UseVisualStyleBackColor = true;
            btnEditCancel.Click += btnEditCancel_Click;
            // 
            // btnEditConfirmChanges
            // 
            btnEditConfirmChanges.Location = new Point(204, 258);
            btnEditConfirmChanges.Margin = new Padding(2);
            btnEditConfirmChanges.Name = "btnEditConfirmChanges";
            btnEditConfirmChanges.Size = new Size(175, 40);
            btnEditConfirmChanges.TabIndex = 13;
            btnEditConfirmChanges.Text = "Confirm Changes";
            btnEditConfirmChanges.UseVisualStyleBackColor = true;
            btnEditConfirmChanges.Click += btnEditConfirmChanges_Click;
            // 
            // txtEditProductDescription
            // 
            txtEditProductDescription.Location = new Point(348, 169);
            txtEditProductDescription.Margin = new Padding(2);
            txtEditProductDescription.Multiline = true;
            txtEditProductDescription.Name = "txtEditProductDescription";
            txtEditProductDescription.Size = new Size(279, 81);
            txtEditProductDescription.TabIndex = 12;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(204, 166);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(138, 19);
            label5.TabIndex = 11;
            label5.Text = "Product Description:";
            // 
            // txtEditPrice
            // 
            txtEditPrice.Location = new Point(316, 137);
            txtEditPrice.Margin = new Padding(2);
            txtEditPrice.Name = "txtEditPrice";
            txtEditPrice.Size = new Size(312, 27);
            txtEditPrice.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(204, 134);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(43, 19);
            label4.TabIndex = 9;
            label4.Text = "Price:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(204, 104);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(71, 19);
            label3.TabIndex = 7;
            label3.Text = "Quantity:";
            // 
            // txtEditProductID
            // 
            txtEditProductID.Location = new Point(316, 72);
            txtEditProductID.Margin = new Padding(2);
            txtEditProductID.Name = "txtEditProductID";
            txtEditProductID.Size = new Size(312, 27);
            txtEditProductID.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(204, 70);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(80, 19);
            label2.TabIndex = 5;
            label2.Text = "Product ID:";
            // 
            // txtEditProductName
            // 
            txtEditProductName.Location = new Point(316, 40);
            txtEditProductName.Margin = new Padding(2);
            txtEditProductName.Name = "txtEditProductName";
            txtEditProductName.Size = new Size(243, 27);
            txtEditProductName.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(204, 37);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(105, 19);
            label1.TabIndex = 3;
            label1.Text = "Product Name:";
            // 
            // lstEditProducts
            // 
            lstEditProducts.FormattingEnabled = true;
            lstEditProducts.Location = new Point(4, 11);
            lstEditProducts.Margin = new Padding(2);
            lstEditProducts.Name = "lstEditProducts";
            lstEditProducts.Size = new Size(191, 289);
            lstEditProducts.TabIndex = 0;
            lstEditProducts.SelectedIndexChanged += lstEditProducts_SelectedIndexChanged;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(pictureBox2);
            tabPage2.Controls.Add(nudSalary);
            tabPage2.Controls.Add(dtpEmployeeStartDate);
            tabPage2.Controls.Add(btnCancelEmployee);
            tabPage2.Controls.Add(btnAddEmployee);
            tabPage2.Controls.Add(txtEmployeeEmail);
            tabPage2.Controls.Add(label12);
            tabPage2.Controls.Add(txtEmployeePhoneNumber);
            tabPage2.Controls.Add(label11);
            tabPage2.Controls.Add(label10);
            tabPage2.Controls.Add(label9);
            tabPage2.Controls.Add(txtEmployeeAddress);
            tabPage2.Controls.Add(label8);
            tabPage2.Controls.Add(txtEmployeeLastName);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(txtEmployeeFirstName);
            tabPage2.Controls.Add(label6);
            tabPage2.Controls.Add(lstEmployees);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Margin = new Padding(2);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(2);
            tabPage2.Size = new Size(635, 305);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Employee";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(566, 0);
            pictureBox2.Margin = new Padding(2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(65, 59);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 28;
            pictureBox2.TabStop = false;
            // 
            // nudSalary
            // 
            nudSalary.Location = new Point(412, 209);
            nudSalary.Margin = new Padding(2);
            nudSalary.Name = "nudSalary";
            nudSalary.Size = new Size(218, 27);
            nudSalary.TabIndex = 27;
            // 
            // dtpEmployeeStartDate
            // 
            dtpEmployeeStartDate.Location = new Point(90, 209);
            dtpEmployeeStartDate.Margin = new Padding(2);
            dtpEmployeeStartDate.Name = "dtpEmployeeStartDate";
            dtpEmployeeStartDate.Size = new Size(266, 27);
            dtpEmployeeStartDate.TabIndex = 26;
            // 
            // btnCancelEmployee
            // 
            btnCancelEmployee.Location = new Point(487, 237);
            btnCancelEmployee.Margin = new Padding(2);
            btnCancelEmployee.Name = "btnCancelEmployee";
            btnCancelEmployee.Size = new Size(135, 56);
            btnCancelEmployee.TabIndex = 25;
            btnCancelEmployee.Text = "Cancel";
            btnCancelEmployee.UseVisualStyleBackColor = true;
            // 
            // btnAddEmployee
            // 
            btnAddEmployee.Location = new Point(358, 237);
            btnAddEmployee.Margin = new Padding(2);
            btnAddEmployee.Name = "btnAddEmployee";
            btnAddEmployee.Size = new Size(126, 56);
            btnAddEmployee.TabIndex = 24;
            btnAddEmployee.Text = "Add Employee";
            btnAddEmployee.UseVisualStyleBackColor = true;
            // 
            // txtEmployeeEmail
            // 
            txtEmployeeEmail.Location = new Point(90, 270);
            txtEmployeeEmail.Margin = new Padding(2);
            txtEmployeeEmail.Name = "txtEmployeeEmail";
            txtEmployeeEmail.Size = new Size(265, 27);
            txtEmployeeEmail.TabIndex = 23;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(4, 267);
            label12.Margin = new Padding(2, 0, 2, 0);
            label12.Name = "label12";
            label12.Size = new Size(49, 19);
            label12.TabIndex = 22;
            label12.Text = "Email:";
            // 
            // txtEmployeePhoneNumber
            // 
            txtEmployeePhoneNumber.Location = new Point(90, 237);
            txtEmployeePhoneNumber.Margin = new Padding(2);
            txtEmployeePhoneNumber.Name = "txtEmployeePhoneNumber";
            txtEmployeePhoneNumber.Size = new Size(265, 27);
            txtEmployeePhoneNumber.TabIndex = 21;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(4, 235);
            label11.Margin = new Padding(2, 0, 2, 0);
            label11.Name = "label11";
            label11.Size = new Size(68, 19);
            label11.TabIndex = 20;
            label11.Text = "Phone #:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(358, 209);
            label10.Margin = new Padding(2, 0, 2, 0);
            label10.Name = "label10";
            label10.Size = new Size(50, 19);
            label10.TabIndex = 18;
            label10.Text = "Salary:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(4, 204);
            label9.Margin = new Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new Size(74, 19);
            label9.TabIndex = 16;
            label9.Text = "Start Date:";
            // 
            // txtEmployeeAddress
            // 
            txtEmployeeAddress.Location = new Point(90, 142);
            txtEmployeeAddress.Margin = new Padding(2);
            txtEmployeeAddress.Multiline = true;
            txtEmployeeAddress.Name = "txtEmployeeAddress";
            txtEmployeeAddress.Size = new Size(541, 56);
            txtEmployeeAddress.TabIndex = 15;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(4, 138);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(62, 19);
            label8.TabIndex = 14;
            label8.Text = "Address:";
            // 
            // txtEmployeeLastName
            // 
            txtEmployeeLastName.Location = new Point(412, 113);
            txtEmployeeLastName.Margin = new Padding(2);
            txtEmployeeLastName.Name = "txtEmployeeLastName";
            txtEmployeeLastName.Size = new Size(221, 27);
            txtEmployeeLastName.TabIndex = 13;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(327, 115);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(80, 19);
            label7.TabIndex = 12;
            label7.Text = "Last Name:";
            // 
            // txtEmployeeFirstName
            // 
            txtEmployeeFirstName.Location = new Point(90, 113);
            txtEmployeeFirstName.Margin = new Padding(2);
            txtEmployeeFirstName.Name = "txtEmployeeFirstName";
            txtEmployeeFirstName.Size = new Size(232, 27);
            txtEmployeeFirstName.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(4, 110);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(83, 19);
            label6.TabIndex = 10;
            label6.Text = "First Name:";
            // 
            // lstEmployees
            // 
            lstEmployees.FormattingEnabled = true;
            lstEmployees.Location = new Point(4, 6);
            lstEmployees.Margin = new Padding(2);
            lstEmployees.Name = "lstEmployees";
            lstEmployees.Size = new Size(560, 99);
            lstEmployees.TabIndex = 0;
            // 
            // fileSystemWatcher1
            // 
            fileSystemWatcher1.EnableRaisingEvents = true;
            fileSystemWatcher1.SynchronizingObject = this;
            // 
            // ProjectAdmin
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(656, 355);
            Controls.Add(tabControl1);
            Font = new Font("Tempus Sans ITC", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(2);
            Name = "ProjectAdmin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Albert, Sadia, Nev";
            Load += ProjectAdmin_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudEditQuantity).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudSalary).EndInit();
            ((System.ComponentModel.ISupportInitialize)fileSystemWatcher1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private ListBox lstEditProducts;
        private TabPage tabPage2;
        private TextBox txtEditProductDescription;
        private Label label5;
        private TextBox txtEditPrice;
        private Label label4;
        private Label label3;
        private TextBox txtEditProductID;
        private Label label2;
        private TextBox txtEditProductName;
        private Label label1;
        private Button btnEditCancel;
        private Button btnEditConfirmChanges;
        private NumericUpDown nudEditQuantity;
        private ListBox lstEmployees;
        private FileSystemWatcher fileSystemWatcher1;
        private Button btnCancelEmployee;
        private Button btnAddEmployee;
        private TextBox txtEmployeeEmail;
        private Label label12;
        private TextBox txtEmployeePhoneNumber;
        private Label label11;
        private Label label10;
        private Label label9;
        private TextBox txtEmployeeAddress;
        private Label label8;
        private TextBox txtEmployeeLastName;
        private Label label7;
        private TextBox txtEmployeeFirstName;
        private Label label6;
        private NumericUpDown nudSalary;
        private DateTimePicker dtpEmployeeStartDate;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private RadioButton radCreate;
        private RadioButton radEdit;
    }
}