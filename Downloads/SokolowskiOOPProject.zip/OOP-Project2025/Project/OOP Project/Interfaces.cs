﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Project
{
    public interface IMagic
    {
        public int PowerLevel { get; set; }
    }
    public interface IHoly : IMagic
    {
        public bool Blessed { get; set; }
    }
    public interface IUnholy : IMagic
    {
        public bool Cursed { get; set; }
    }
}
