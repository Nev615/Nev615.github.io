﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Project
{
    public partial class ProjectAdmin : Form
    {
        Inventory inv = new Inventory();
        private List<Employee> employees = new List<Employee>();
        private string employeesFilePath = "employees.txt";

        public ProjectAdmin()
        {
            InitializeComponent();
        }


        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee
            {
                FirstName = txtEmployeeFirstName.Text.Trim(),
                LastName = txtEmployeeLastName.Text.Trim(),
                Address = txtEmployeeAddress.Text.Trim(),
                StartDate = dtpEmployeeStartDate.Value,
                Salary = nudSalary.Value,
                PhoneNumber = txtEmployeePhoneNumber.Text.Trim(),
                Email = txtEmployeeEmail.Text.Trim()
            };

            employees.Add(emp);
            lstEmployees.Items.Add(emp);
            ClearForm();
        }

        private void ClearForm()
        {
            txtEmployeeFirstName.Text = "";
            txtEmployeeLastName.Text = "";
            txtEmployeeAddress.Text = "";
            dtpEmployeeStartDate.Value = DateTime.Today;
            nudSalary.Value = 0;
            txtEmployeePhoneNumber.Text = "";
            txtEmployeeEmail.Text = "";
        }

        private void LoadProductFile()
        {
            inv.Products = ExtractProducts.FilterItems();
        }

        private void lstEditProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (radEdit.Checked == true)
            {

                Product selectedProduct = lstEditProducts.SelectedItem as Product;
                txtEditProductID.Text = selectedProduct.ProductID.ToString();
                txtEditProductName.Text = selectedProduct.Name;
                nudEditQuantity.Text = selectedProduct.Quantity.ToString();
                txtEditPrice.Text = selectedProduct.Price.ToString();
                txtEditProductDescription.Text = selectedProduct.Description;
            }
        }

        private void btnEditConfirmChanges_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(txtEditProductID.Text.Trim());
                string name = txtEditProductName.Text.Trim();
                int quantity = int.TryParse(nudEditQuantity.Text.Trim(), out int q) ? q : 0;
                decimal price = decimal.TryParse(txtEditPrice.Text.Trim(), out decimal p) ? p : 0;
                string desc = txtEditProductDescription.Text.Trim();

                if (radEdit.Checked == true)
                {
                    Product selectedProduct = (Product)lstEditProducts.SelectedItem;
                    selectedProduct.ProductID = id;
                    selectedProduct.Name = name;
                    selectedProduct.Quantity = quantity;
                    selectedProduct.Price = price;
                    selectedProduct.Description = desc;

                    SaveProductsToFile();

                    MessageBox.Show($@"Product {selectedProduct.Name} Updated.");
                }
                else
                {
                    Artifact art = new Artifact(id, quantity, name, desc, price, 5, "Generally very magical", "You tell me");
                    inv.Products.Add(art);

                    SaveProductsToFile();
                    lstEditProducts.DataSource = null;
                    lstEditProducts.DataSource = inv.Products;

                    MessageBox.Show($@"Product {art.Name} added to Products.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void SaveProductsToFile()
        {
            string path = "inventory.txt";

            if (File.Exists(path))
            {
                try
                {
                    List<string> lines = inv.Products.Select(p => p.SaveInfo()).ToList();
                    File.WriteAllLines(path, lines);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnEditCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ProjectAdmin_Load(object sender, EventArgs e)
        {
            LoadProductFile();
            LoadEmployeesFromFile();
            lstEditProducts.DataSource = null;
            lstEditProducts.DataSource = inv.Products;
            lstEditProducts.ClearSelected();
            radEdit.Checked = true;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radEdit.Checked == true)
            {
                lstEditProducts.Enabled = true;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radCreate.Checked == true)
            {
                lstEditProducts.Enabled = false;
                txtEditPrice.Text = "";
                txtEditProductDescription.Text = "";
                txtEditProductID.Text = "";
                txtEditProductName.Text = "";
                nudEditQuantity.Value = 0;
            }
        }

        private void LoadEmployeesFromFile()
        {
            if (File.Exists(employeesFilePath))
            {
                string[] lines = File.ReadAllLines(employeesFilePath);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length >= 7)
                    {
                        Employee emp = new Employee
                        {
                            FirstName = parts[0],
                            LastName = parts[1],
                            Address = parts[2],
                            StartDate = DateTime.TryParse(parts[3], out DateTime date) ? date : DateTime.Today,
                            Salary = decimal.TryParse(parts[4], out decimal sal) ? sal : 0,
                            PhoneNumber = parts[5],
                            Email = parts[6]
                        };

                        employees.Add(emp);
                        lstEmployees.Items.Add(emp);
                    }
                }
            }

        }


    }
}
