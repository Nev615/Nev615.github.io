﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Project
{
    public partial class ChangePassword : Form
    {
        UserHandler userHandler;
        public ChangePassword()
        {
            InitializeComponent();
        }

        private void ChangePassword_Load(object sender, EventArgs e)
        {
            txtCurrentPassword.PasswordChar = '*';
            txtNewPassword.PasswordChar = '*';
            userHandler = new UserHandler();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            bool found = false;
            bool passPass = false;
            string currentPassword = txtCurrentPassword.Text;
            string username = txtUsername.Text;
            string newPassword = txtNewPassword.Text;
            List<User> users = userHandler.GetUsers();
            foreach (User user in users)
            {
                if (user.Name == username)
                {
                    found = true;
                    if(user.Password == currentPassword)
                    {
                        passPass = true;
                        if(newPassword.Length > 0)
                        {
                            user.Password = newPassword;
                        }
                        else
                        {
                            MessageBox.Show("Password can not be empty", "Error");
                        }
                        
                    }
                }

            }
            if (found && passPass && newPassword.Length != 0)
            {
                userHandler.SaveUsers(users);
                userHandler.readFile();
                this.Close();
            }
            else if(found && !passPass)
            {
                MessageBox.Show("Password is incorrect", "Error");
            }else if (!found)
            {
                MessageBox.Show("Username not found", "error");
            }
            
        }
    }
}
