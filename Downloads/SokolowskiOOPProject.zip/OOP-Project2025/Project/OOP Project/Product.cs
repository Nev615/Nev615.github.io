﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace OOP_Project
{
    public abstract class Product
    {
        private int quantity;

        public int ProductID { get; set; }
        public int Quantity
        {
            get
            {
                return quantity;
            }
            set
            {
                quantity = value;

                if (quantity == 0)
                    InStock = false;
                else
                    InStock = true;

            }
        }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public bool InStock { get; set; }

        

        public Product(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice)
        {
            ProductID = inProductID;
            Quantity = inQuantity;
            Name = inName;
            Description = inDescription;
            Price = inPrice;
        }

        public Product()
        {

        }

        public override string ToString()
        {
            return string.Format("{0, -10} {1, -20} {2, -1} {3, -10}", ProductID, Name, "x", Quantity);
        }

        public virtual string DisplayInfo()
        {
            string info =
            $"Product Name: {Name}\n\n" +
            $"Product ID: {ProductID}\n\n" +
            $"Quantity: {Quantity}\n\n" +
            $"Price: {Price.ToString("c")}\n\n" +
            $"Description: {Description}\n\n";

           return info;
        }

        public virtual string SaveInfo()
        {
            return $@"{this.GetType().Name}-{ProductID}-{Quantity.ToString()}-{Name}-{Description}-{Price.ToString()}-";
        }
    }

    

    public class Weapon : Product
    {
        public string EffectiveAgainst { get; set; }
        public string Material { get; set; }

        public Weapon(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice,
            string inEffectiveAgainst, string inMaterial) 
            : base(inProductID, inQuantity, inName, inDescription, inPrice)
        {
            EffectiveAgainst = inEffectiveAgainst;
            Material = inMaterial;
        }

        public Weapon()
        {

        }

        public override string DisplayInfo()
        {
            string info =
            base.DisplayInfo() +
            $"Useful Against: {EffectiveAgainst}\n" +
            $"Material: {Material}";

            return info;
        }

        public override string SaveInfo()
        {
            return base.SaveInfo() + $@"{EffectiveAgainst}-{Material}";
        }

        public static Weapon operator +(Weapon p1, HolyWater p2)
        {
            Weapon wep = null;

            if (p1.InStock == true && p2.InStock == true)
            {
                p1.Quantity--;
                p2.Quantity--;

                return p1;

            }
            else if (p1.InStock == false)
            {
                MessageBox.Show($@"{p1.Name} out of Stock.");
                return wep;
            }
            else if (p2.InStock == false)
            {
                MessageBox.Show($@"{p2.Name} out of Stock.");
                return wep;
            }
            else
                return wep;
        }

        public static Weapon operator -(Weapon p1, BlackWater p2)
        {
            Weapon wep = null;

            if (p1.InStock == true && p2.InStock == true)
            {
                p1.Quantity--;
                p2.Quantity--;

                return p1;

            }
            else if (p1.InStock == false)
            {
                MessageBox.Show($@"{p1.Name} out of Stock.");
                return wep;
            }
            else if (p2.InStock == false)
            {
                MessageBox.Show($@"{p2.Name} out of Stock.");
                return wep;
            }
            else
                return wep;
        }
        
    }

    public sealed class HolyWeapon : Weapon, IHoly
    {
     
        public bool Blessed { get; set; }
        public int PowerLevel { get; set; }

        public HolyWeapon(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice,
            string inEffectiveAgainst, string inMaterial, bool inBlessed, int inPowerLevel) 
            : base(inProductID, inQuantity, inName, inDescription, inPrice, inEffectiveAgainst, inMaterial)
        {
            Blessed = inBlessed;
            PowerLevel = inPowerLevel;
            Price = inPrice;
        }

        public HolyWeapon()
        {

        }

        public override string DisplayInfo()
        {
            string info =
            base.DisplayInfo() + "\n" +
            $"Blessed: {Blessed}\n" +
            $"Power Level: {PowerLevel}";

            return info;
        }

        public override string SaveInfo()
        {
            return base.SaveInfo() + $@"-{Blessed}-{PowerLevel}";
        }
    }

    public  sealed class UnHolyWeapon : Weapon, IUnholy
    {
        public bool Cursed { get; set; }
        public int PowerLevel { get; set; }

        public UnHolyWeapon(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice,
            string inEffectiveAgainst, string inMaterial, bool inCursed, int inPowerLevel)
            : base(inProductID, inQuantity, inName, inDescription, inPrice, inEffectiveAgainst, inMaterial)
        {
            Cursed = inCursed;
            PowerLevel = inPowerLevel;
        }

        public UnHolyWeapon()
        {

        }

        public void CursedDiscount()
        {
            if(Cursed == true)
                Price = Price * .5m;
            else
                Price = Price;
        }

        public override string DisplayInfo()
        {
            string info =
            base.DisplayInfo() +"\n" +
            $"Cursed: {Cursed}\n" +
            $"Power Level: {PowerLevel}";

            return info;
        }

        public override string SaveInfo()
        {
            return base.SaveInfo() + $@"-{Cursed}-{PowerLevel}";
        }
    }

    public class Book : Product
    {
        public string Subject { get; set; }
        public int Pages { get; set; }

        public Book(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice,
            string inSubject, int inPages) : base(inProductID, inQuantity, inName, inDescription, inPrice)
        {
            Subject = inSubject;
            Pages = inPages;
        }

        public Book()
        {

        }

        public override string DisplayInfo()
        {
            string info =
            base.DisplayInfo() +
            $"Subject: {Subject}\n" +
            $"Pages: {Pages}\n";
            return info;
        }

        public override string SaveInfo()
        {
            return base.SaveInfo() + $@"{Subject}-{Pages.ToString()}";
        }
    }

    public class SpellBook : Book, IMagic
    {
        public int PowerLevel { get; set; }

        public SpellBook(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice,
           string inSubject, int inPages, int inPowerLevel) 
            : base(inProductID, inQuantity, inName, inDescription, inPrice, inSubject, inPages)
        {
            PowerLevel = inPowerLevel;
        }

        public SpellBook()
        {

        }

        public override string DisplayInfo()
        {
            string info =
            base.DisplayInfo() + "\n" +
            $"Power Level: {PowerLevel}";

            return info;
        }

        public override string SaveInfo()
        {
            return base.SaveInfo() + $@"-{PowerLevel}";
        }
    }

    public class Artifact : Product, IMagic
    {
        public int PowerLevel { get; set; }
        public string UseCase { get; set; }
        public string Vibe { get; set; }

        public Artifact(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice,
            int inPowerLevel, string inUseCase, string inVibe)
            : base (inProductID, inQuantity, inName, inDescription, inPrice)
        {
            PowerLevel = inPowerLevel;
            UseCase = inUseCase;
            Vibe = inVibe;
        }

        public Artifact()
        {

        }

        public override string DisplayInfo()
        {
            string info =
            base.DisplayInfo() +
            $"Useful For: {UseCase}\n" +
            $"Vibe: {Vibe}\n" +
            $"Power Level: {PowerLevel}";

            return info;
        }

        public override string SaveInfo()
        {
            return base.SaveInfo() + $@"{PowerLevel}-{UseCase}-{Vibe}";
        }

        public static Artifact operator +(Artifact p1, HolyWater p2)
        {
            Artifact art = null;

            if (p1.InStock == true && p2.InStock == true)
            {
                p1.Quantity--;
                p2.Quantity--;

                return p1;
            }
            else if (p1.InStock == false)
            {
                MessageBox.Show($@"{p1.Name} out of Stock.");
                return art;
            }
            else if (p2.InStock == false)
            {
                MessageBox.Show($@"{p2.Name} out of Stock.");
                return art;
            }
            else
                return art;
        }

        public static Artifact operator -(Artifact p1, BlackWater p2)
        {
            Artifact art = null;

            if (p1.InStock == true && p2.InStock == true)
            {
                p1.Quantity--;
                p2.Quantity--;

                return p1;
            }
            else if (p1.InStock == false)
            {
                MessageBox.Show($@"{p1.Name} out of Stock.");
                return art;
            }
            else if (p2.InStock == false)
            {
                MessageBox.Show($@"{p2.Name} out of Stock.");
                return art;
            }
            else
                return art;
        }
    }

    public sealed class HolyArtifact : Artifact, IHoly
    {
        public bool Blessed { get; set; }
        public HolyArtifact(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice,
            int inPowerLevel, string inUseCase, string inVibe, bool inBlessed)
            : base(inProductID, inQuantity, inName, inDescription, inPrice, inPowerLevel, inUseCase, inVibe)
        {
            Blessed = inBlessed;
        }

        public HolyArtifact()
        {

        }

        public void UnBlessedDiscount()
        {
            if (Blessed == false)
                Price = Price * .85m;
            else
                Price = Price;
        }

        public override string DisplayInfo()
        {
            string info =
            base.DisplayInfo() + "\n" +
            $"Blessed: {Blessed}";

            return info;
        }
        public override string SaveInfo()
        {
            return base.SaveInfo() + $@"-{Blessed}";
        }

    }

    public sealed class UnHolyArtifact : Artifact, IUnholy
    {
        public bool Cursed { get; set; }
        public UnHolyArtifact(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice,
           int inPowerLevel, string inUseCase, string inVibe, bool inCursed)
           : base(inProductID, inQuantity, inName, inDescription, inPrice, inPowerLevel, inUseCase, inVibe)
        {
            Cursed = inCursed;
        }

        public UnHolyArtifact()
        {

        }

        public void CursedDiscount()
        {
            if (Cursed == true)
                Price = Price * .5m;
            else
                Price = Price;
        }

        public override string DisplayInfo()
        {
            string info =
            base.DisplayInfo() + "\n" +
            $"Cursed: {Cursed}";

            return info;
        }
        public override string SaveInfo()
        {
            return base.SaveInfo() + $@"-{Cursed}";
        }
    }

    public class Ingredient : Product
    {
        public string Application { get; set; }
        public string Warnings { get; set; }

        public Ingredient(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice,
            string inApplication, string inWarnings) : base(inProductID, inQuantity, inName, inDescription, inPrice)
        {
            Application = inApplication;
            Warnings = inWarnings;
        }

        public Ingredient()
        {

        }

        public override string DisplayInfo()
        {
            string info =
            base.DisplayInfo() +
            $"Application: {Application}\n" +
            $"Warnings: {Warnings}\n";

            return info;
        }
        public override string SaveInfo()
        {
            return base.SaveInfo() + $@"{Application}-{Warnings}";
        }
    }

    public sealed class HolyWater : Ingredient, IHoly
    {
        public bool Blessed { get; set; }
        public int PowerLevel { get; set; }

        public HolyWater(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice,
            string inApplication, string inWarnings, bool inBlessed, int inPowerLevel) : base(inProductID, inQuantity, inName, inDescription, inPrice, inApplication, inWarnings)
        {
            ProductID = 777;
            Quantity = inQuantity;
            Name = "Holy Water";
            Description = "Blessed at our local Parish by Father Kincaid, this is a classic tool against vampires. " +
                "It is also a specialty item that has several applications with our products. Try applying it to different items!";
            Price = 77.77m;
            Application = "Can be applied to weapons and artifacts: Ordaining a nonholy item, blessing an Ordained item, or removing a curse from a Cursed item.";
            Warnings = "Do not handle if you are cursed or of known demonic heritage.";
            PowerLevel = 7;
            Blessed = inBlessed;
        }

        public HolyWater()
        {

        }

        public void UnBlessedDiscount()
        {
            MessageBox.Show("It's literally called Holy Water");
            Blessed = true;
        }

        public override string DisplayInfo()
        {
            string info =
            base.DisplayInfo() +
            $"Blessed: {Blessed}\n" +
            $"Power Level: {PowerLevel}";

            return info;
        }

        public override string SaveInfo()
        {
            return base.SaveInfo() + $@"-{Blessed}-{PowerLevel}";
        }
    }

    public sealed class BlackWater : Ingredient, IUnholy
    {
        public bool Cursed { get; set; }
        public int PowerLevel { get; set; }
        public BlackWater(int inProductID, int inQuantity, string inName, string inDescription, decimal inPrice,
           string inApplication, string inWarnings, bool inCursed, int inPowerLevel) : base(inProductID, inQuantity, inName, inDescription, inPrice, inApplication, inWarnings)
        {
            ProductID = 666;
            Quantity = inQuantity;
            Name = "Black Water";
            Description = "In compliance with WSS, we are required to keep a stock of Black Water on site. If someone or something you know needs cursing," +
                " we have the product for you! Feel free to try it out on products in our shop! " +
                "*We are not responsible for damages resulting from curses applied with this product.";
            Price = 6.66m;
            Application = "Can be applied to weapons and artifacts: Corrupting a nonholy item, cursing an Unholy item, or removing a blessing from a Holy item.";
            Warnings = "Many bad things can result from using this product.";
            PowerLevel = 6;
            Cursed = inCursed;
        }

        public BlackWater()
        {

        }

        public void CursedDiscount()
        {
            MessageBox.Show("It's cursed. Trust us.");
            Cursed = true;
        }

        public override string DisplayInfo()
        {
            string info =
            base.DisplayInfo() +
            $"Cursed: {Cursed}\n" +
            $"Power Level: {PowerLevel}";

            return info;
        }

        public override string SaveInfo()
        {
            return base.SaveInfo() + $@"-{Cursed}-{PowerLevel}";
        }
    }

    public class Inventory
    {
        public List<Product> Products { get; set; }
        public List<Product> Cart { get; set; }
        public string Receipt { get; set; }

        public Inventory()
        {
            Products = new List<Product>();
            Cart = new List<Product>();
            Receipt = "";
        }
    }
}
