﻿namespace OOP_Project
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstDisplay = new ListBox();
            lblDisplay = new Label();
            cboCategory = new ComboBox();
            btnAdd = new Button();
            btnCart = new Button();
            label1 = new Label();
            btnHoly = new Button();
            btnBlack = new Button();
            pictureBox1 = new PictureBox();
            nudQuantity = new NumericUpDown();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).BeginInit();
            SuspendLayout();
            // 
            // lstDisplay
            // 
            lstDisplay.Font = new Font("Tempus Sans ITC", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lstDisplay.FormattingEnabled = true;
            lstDisplay.Location = new Point(598, 86);
            lstDisplay.Name = "lstDisplay";
            lstDisplay.Size = new Size(366, 384);
            lstDisplay.TabIndex = 0;
            lstDisplay.SelectedIndexChanged += lstDisplay_SelectedIndexChanged;
            // 
            // lblDisplay
            // 
            lblDisplay.BackColor = SystemColors.ControlLightLight;
            lblDisplay.BorderStyle = BorderStyle.FixedSingle;
            lblDisplay.Font = new Font("Tempus Sans ITC", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDisplay.Location = new Point(12, 86);
            lblDisplay.Name = "lblDisplay";
            lblDisplay.Size = new Size(564, 384);
            lblDisplay.TabIndex = 1;
            // 
            // cboCategory
            // 
            cboCategory.FormattingEnabled = true;
            cboCategory.Items.AddRange(new object[] { "All Items", "Weapons", "Books", "Artifacts", "Ingredients", "Magic Items", "Holy Items", "Unholy Items" });
            cboCategory.Location = new Point(598, 36);
            cboCategory.Name = "cboCategory";
            cboCategory.Size = new Size(151, 27);
            cboCategory.TabIndex = 2;
            cboCategory.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(982, 152);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(150, 76);
            btnAdd.TabIndex = 3;
            btnAdd.Text = "Add to Cart";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnCart
            // 
            btnCart.Location = new Point(982, 246);
            btnCart.Name = "btnCart";
            btnCart.Size = new Size(150, 76);
            btnCart.TabIndex = 5;
            btnCart.Text = "View Cart";
            btnCart.UseVisualStyleBackColor = true;
            btnCart.Click += btnCart_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(773, 36);
            label1.Name = "label1";
            label1.Size = new Size(140, 19);
            label1.TabIndex = 6;
            label1.Text = "Browse by Category!";
            // 
            // btnHoly
            // 
            btnHoly.Location = new Point(982, 344);
            btnHoly.Name = "btnHoly";
            btnHoly.Size = new Size(150, 55);
            btnHoly.TabIndex = 7;
            btnHoly.Text = "Apply Holy Water";
            btnHoly.UseVisualStyleBackColor = true;
            btnHoly.Click += btnHoly_Click;
            // 
            // btnBlack
            // 
            btnBlack.Location = new Point(982, 405);
            btnBlack.Name = "btnBlack";
            btnBlack.Size = new Size(150, 55);
            btnBlack.TabIndex = 8;
            btnBlack.Text = "Apply Black Water";
            btnBlack.UseVisualStyleBackColor = true;
            btnBlack.Click += btnBlack_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.image;
            pictureBox1.Location = new Point(1065, 15);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(67, 62);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // nudQuantity
            // 
            nudQuantity.Location = new Point(982, 108);
            nudQuantity.Name = "nudQuantity";
            nudQuantity.RightToLeft = RightToLeft.No;
            nudQuantity.Size = new Size(150, 27);
            nudQuantity.TabIndex = 10;
            nudQuantity.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(982, 77);
            label2.Name = "label2";
            label2.Size = new Size(71, 19);
            label2.TabIndex = 11;
            label2.Text = "Quantity:";
            // 
            // CustomerForm
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1154, 479);
            Controls.Add(label2);
            Controls.Add(nudQuantity);
            Controls.Add(pictureBox1);
            Controls.Add(btnBlack);
            Controls.Add(btnHoly);
            Controls.Add(label1);
            Controls.Add(btnCart);
            Controls.Add(btnAdd);
            Controls.Add(cboCategory);
            Controls.Add(lblDisplay);
            Controls.Add(lstDisplay);
            Font = new Font("Tempus Sans ITC", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "CustomerForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Albert, Sadia, Nev";
            Load += CustomerForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox lstDisplay;
        private Label lblDisplay;
        private ComboBox cboCategory;
        private Button btnAdd;
        private Button btnRemove;
        private Button btnCart;
        private Label label1;
        private Button btnHoly;
        private Button btnBlack;
        private PictureBox pictureBox1;
        private NumericUpDown nudQuantity;
        private Label label2;
        //private PictureBox pictureBox1;
    }
}