﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Project
{
    public class User
    {
        // Fields
        private int _userID;
        private string _password;
        private string _name;
        private bool access;


        // Constructors
        public User() { }
        // Properties
        public int UserID { get { return _userID; } set { _userID = value; } }
        public string Password { get { return _password; } set { _password = value; } }
        public string Name { get { return _name; } set { _name = value; } }
        public bool Access { get { return access; } set { access = value; } }

        // Methods

    }

    public class Customer : User
    {
        // Constructors
        public Customer(string in_name, string in_password, int in_userID)
        {
            this.Access = false;
            this.Name = in_name;
            this.Password = in_password;
            this.UserID = in_userID;
        }

        public override string ToString()
        {
            return "Customer" + "," + Name + "," + Password;
        }
    }
    public class Admin : User
    {
        // Constructors
        public Admin(string in_name, string in_password, int in_userID)
        {
            this.Access = true;
            this.Name = in_name;
            this.Password = in_password;
            this.UserID = in_userID;
        }
        public override string ToString()
        {
            return "Admin" + "," + Name + "," + Password;
        }
    }
}
