﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Project
{
    public partial class LoginPage : Form
    {
        List<User> users = new List<User>();
        bool isCustomer = true;
        public LoginPage()
        {
            InitializeComponent();
        }
        private void LoginPage_Load(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
            // Get Users
            GetUsers();

        }

        private void btnLogin_Click_1(object sender, EventArgs e)
        {
            Login();
        }

        private void Login()
        {
            string userName = txtUsername.Text;
            string password = txtPassword.Text;
            bool canLogIn = CheckPassword(userName, password);
            if (canLogIn && isCustomer)
            {
                // Initialize Page for Customer
                //CustomerForm custForm = new CustomerForm(this);
                CustomerForm custForm = new CustomerForm();
                this.Hide();
                custForm.ShowDialog();
                this.Close();
            }
            else if (canLogIn && !isCustomer)
            {
                // Initializa Page for Admin
                this.Hide();
                ProjectAdmin adminForm = new ProjectAdmin();
                adminForm.ShowDialog();
                this.Close();

            }
            if (!canLogIn)
            {
                MessageBox.Show("Invalid Credentials", "Alert");
            }
            //MessageBox.Show("" + canLogIn);
        }

        private void GetUsers()
        {
            UserHandler userHandler = new UserHandler();
            users = userHandler.GetUsers();
        }

        public bool CheckPassword(string userName, string password)
        {
            for (int z = 0; z < users.Count; z++)
            {
                if (users[z].Name == userName)
                {
                    if (users[z].Password == password)
                    {
                        if (users[z].Access)
                        {
                            isCustomer = false;
                        }
                        return true;
                    }
                }
            }
            return false;

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            ChangePassword changePassword = new ChangePassword();
            changePassword.ShowDialog();
            GetUsers();
        }
    }
}
