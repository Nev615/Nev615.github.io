﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Project
{
    public partial class checkout : Form
    {



        public checkout()
        {
            InitializeComponent();
        }

        Inventory list = null;

        public checkout(Inventory inv)
        {
            InitializeComponent();
            list = inv;
        }

        private void btnSubmitPurchase_Click(object sender, EventArgs e)
        {
            if (lstCheckoutProducts.SelectedIndex != -1) // Check if a product is selected
            {
                string itemList = "";

                foreach (Product item in list.Cart)
                {
                    itemList += $"{item.ToString()}\n";
                }

                // Construct purchase information message
                string orderInfo = $"First Name: {txtFirstName.Text}\n" +
                                 $"Last Name: {txtLastName.Text}\n\n" +
                                 $"Phone Number: {txtPhoneNumber.Text}\n" +
                                 $"Mailing Address: {txtMailingAddress.Text}\n" +
                                 $"Delivery Instructions: {txtDeliveryInstruction.Text}\n\n" +
                                 $"{itemList}\n" +
                                 $"{list.Receipt}\n" +
                                 $"Card Number: {txtCardNumber.Text}\n" +
                                 $"Card Security Number: ***\n" +
                                 $"Purchase Complete. Thank you!\n";

                // payment method information based on the selected radio button
                if (radCard.Checked)
                {
                    orderInfo += "\nPayment Method: Card\n";
                }
                else if (radSoul.Checked)
                {
                    orderInfo += "\nPayment Method: Soul\n";
                }



                orderInfo += "Purchase Complete. Thank you!\n";
                orderInfo += "-----------------------------\n";

                string filePath = "orders.txt";

                try
                {
                    // Append the order information to the file
                    File.AppendAllText(filePath, orderInfo);

                    MessageBox.Show("Order saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while saving the order:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // Display a message if no book is selected
                MessageBox.Show("Please select a product to order.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void checkout_Load(object sender, EventArgs e)
        {
            lstCheckoutProducts.DataSource = null;
            lstCheckoutProducts.DataSource = list.Cart;
        }
    }
}
