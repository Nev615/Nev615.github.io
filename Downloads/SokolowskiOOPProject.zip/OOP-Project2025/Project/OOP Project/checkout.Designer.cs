﻿namespace OOP_Project
{
    partial class checkout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSubmitPurchase = new Button();
            txtExpiryDate = new TextBox();
            label8 = new Label();
            txtSecurityNumber = new TextBox();
            label7 = new Label();
            txtCardNumber = new TextBox();
            label6 = new Label();
            txtDeliveryInstruction = new TextBox();
            label5 = new Label();
            txtPhoneNumber = new TextBox();
            label4 = new Label();
            txtMailingAddress = new TextBox();
            label3 = new Label();
            txtLastName = new TextBox();
            label2 = new Label();
            txtFirstName = new TextBox();
            label1 = new Label();
            lstCheckoutProducts = new ListBox();
            label9 = new Label();
            radCard = new RadioButton();
            radSoul = new RadioButton();
            SuspendLayout();
            // 
            // btnSubmitPurchase
            // 
            btnSubmitPurchase.Location = new Point(23, 332);
            btnSubmitPurchase.Margin = new Padding(2);
            btnSubmitPurchase.Name = "btnSubmitPurchase";
            btnSubmitPurchase.Size = new Size(132, 41);
            btnSubmitPurchase.TabIndex = 35;
            btnSubmitPurchase.Text = "Submit Purchase";
            btnSubmitPurchase.UseVisualStyleBackColor = true;
            btnSubmitPurchase.Click += btnSubmitPurchase_Click;
            // 
            // txtExpiryDate
            // 
            txtExpiryDate.Location = new Point(502, 357);
            txtExpiryDate.Margin = new Padding(2);
            txtExpiryDate.Name = "txtExpiryDate";
            txtExpiryDate.Size = new Size(144, 27);
            txtExpiryDate.TabIndex = 34;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(417, 353);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(86, 19);
            label8.TabIndex = 33;
            label8.Text = "Expiry Date:";
            // 
            // txtSecurityNumber
            // 
            txtSecurityNumber.Location = new Point(261, 357);
            txtSecurityNumber.Margin = new Padding(2);
            txtSecurityNumber.Name = "txtSecurityNumber";
            txtSecurityNumber.Size = new Size(127, 27);
            txtSecurityNumber.TabIndex = 32;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(176, 353);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(76, 19);
            label7.TabIndex = 31;
            label7.Text = "Security #:";
            // 
            // txtCardNumber
            // 
            txtCardNumber.Location = new Point(257, 324);
            txtCardNumber.Margin = new Padding(2);
            txtCardNumber.Name = "txtCardNumber";
            txtCardNumber.Size = new Size(389, 27);
            txtCardNumber.TabIndex = 30;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(176, 325);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(56, 19);
            label6.TabIndex = 29;
            label6.Text = "Card #:";
            // 
            // txtDeliveryInstruction
            // 
            txtDeliveryInstruction.Location = new Point(412, 199);
            txtDeliveryInstruction.Margin = new Padding(2);
            txtDeliveryInstruction.Multiline = true;
            txtDeliveryInstruction.Name = "txtDeliveryInstruction";
            txtDeliveryInstruction.Size = new Size(234, 69);
            txtDeliveryInstruction.TabIndex = 28;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(270, 199);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(138, 19);
            label5.TabIndex = 27;
            label5.Text = "Delivery Instruction:";
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.Location = new Point(354, 169);
            txtPhoneNumber.Margin = new Padding(2);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.Size = new Size(291, 27);
            txtPhoneNumber.TabIndex = 26;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(270, 166);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(68, 19);
            label4.TabIndex = 25;
            label4.Text = "Phone #:";
            // 
            // txtMailingAddress
            // 
            txtMailingAddress.Location = new Point(401, 77);
            txtMailingAddress.Margin = new Padding(2);
            txtMailingAddress.Multiline = true;
            txtMailingAddress.Name = "txtMailingAddress";
            txtMailingAddress.Size = new Size(245, 79);
            txtMailingAddress.TabIndex = 24;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(270, 77);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(115, 19);
            label3.TabIndex = 23;
            label3.Text = "Mailing Address:";
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(354, 45);
            txtLastName.Margin = new Padding(2);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(291, 27);
            txtLastName.TabIndex = 22;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(270, 42);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(80, 19);
            label2.TabIndex = 21;
            label2.Text = "Last Name:";
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(354, 11);
            txtFirstName.Margin = new Padding(2);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(291, 27);
            txtFirstName.TabIndex = 20;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(270, 9);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(83, 19);
            label1.TabIndex = 19;
            label1.Text = "First Name:";
            // 
            // lstCheckoutProducts
            // 
            lstCheckoutProducts.FormattingEnabled = true;
            lstCheckoutProducts.Location = new Point(7, 8);
            lstCheckoutProducts.Margin = new Padding(2);
            lstCheckoutProducts.Name = "lstCheckoutProducts";
            lstCheckoutProducts.Size = new Size(253, 308);
            lstCheckoutProducts.TabIndex = 18;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(270, 274);
            label9.Margin = new Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new Size(124, 19);
            label9.TabIndex = 36;
            label9.Text = "Payment Method:";
            // 
            // radCard
            // 
            radCard.AutoSize = true;
            radCard.Location = new Point(273, 295);
            radCard.Margin = new Padding(2);
            radCard.Name = "radCard";
            radCard.Size = new Size(59, 23);
            radCard.TabIndex = 37;
            radCard.TabStop = true;
            radCard.Text = "Card";
            radCard.UseVisualStyleBackColor = true;
            // 
            // radSoul
            // 
            radSoul.AutoSize = true;
            radSoul.Location = new Point(588, 293);
            radSoul.Margin = new Padding(2);
            radSoul.Name = "radSoul";
            radSoul.Size = new Size(57, 23);
            radSoul.TabIndex = 38;
            radSoul.TabStop = true;
            radSoul.Text = "Soul";
            radSoul.UseVisualStyleBackColor = true;
            // 
            // checkout
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(655, 388);
            Controls.Add(radSoul);
            Controls.Add(radCard);
            Controls.Add(label9);
            Controls.Add(btnSubmitPurchase);
            Controls.Add(txtExpiryDate);
            Controls.Add(label8);
            Controls.Add(txtSecurityNumber);
            Controls.Add(label7);
            Controls.Add(txtCardNumber);
            Controls.Add(label6);
            Controls.Add(txtDeliveryInstruction);
            Controls.Add(label5);
            Controls.Add(txtPhoneNumber);
            Controls.Add(label4);
            Controls.Add(txtMailingAddress);
            Controls.Add(label3);
            Controls.Add(txtLastName);
            Controls.Add(label2);
            Controls.Add(txtFirstName);
            Controls.Add(label1);
            Controls.Add(lstCheckoutProducts);
            Font = new Font("Tempus Sans ITC", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(2);
            Name = "checkout";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Albert, Sadia, Nev";
            Load += checkout_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSubmitPurchase;
        private TextBox txtExpiryDate;
        private Label label8;
        private TextBox txtSecurityNumber;
        private Label label7;
        private TextBox txtCardNumber;
        private Label label6;
        private TextBox txtDeliveryInstruction;
        private Label label5;
        private TextBox txtPhoneNumber;
        private Label label4;
        private TextBox txtMailingAddress;
        private Label label3;
        private TextBox txtLastName;
        private Label label2;
        private TextBox txtFirstName;
        private Label label1;
        private ListBox lstCheckoutProducts;
        private Label label9;
        private RadioButton radCard;
        private RadioButton radSoul;
    }
}