﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Project
{
    public partial class CustomerForm : Form
    {
        public CustomerForm()
        {
            InitializeComponent();
        }

        Inventory inv = new Inventory(); 

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            LoadFile();
            cboCategory.SelectedIndex = 0;
            lstDisplay.SelectedIndex = -1;
            lblDisplay.Text = "";
            HideButtons();
        }

        private void HideButtons()
        {
            btnHoly.Hide();
            btnBlack.Hide();
        }

        private void ShowButtons()
        {
            btnHoly.Show();
            btnBlack.Show();
        }

        private void LoadFile()
        {
            inv.Products = ExtractProducts.FilterItems();  
        }

        private void FillListBox<T>()
        {
            var selectType = inv.Products
                        .OfType<T>().ToList();

            lstDisplay.DataSource = null;
            lstDisplay.DataSource = selectType;
        }

        private void lstDisplay_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstDisplay.SelectedIndex >= 0)
            {
                Product p = (Product)lstDisplay.SelectedItem;

                lblDisplay.Text = p.DisplayInfo();

                if (p is Weapon || p is Artifact)
                {
                    ShowButtons();
                }
                else
                {
                    HideButtons();
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboCategory.SelectedIndex >= 0)
            {
                string category = cboCategory.Text;

                RefreshListBox();
            }
        }

        private void RefreshListBox()
        {
            string category = cboCategory.Text;
            int index = lstDisplay.SelectedIndex;

            if (category == "All Items")
            {
                FillListBox<Product>();
            }
            else if (category == "Weapons")
            {
                FillListBox<Weapon>();
            }
            else if (category == "Books")
            {
                FillListBox<Book>();
            }
            else if (category == "Artifacts")
            {
                FillListBox<Artifact>();
            }
            else if (category == "Ingredients")
            {
                FillListBox<Ingredient>();
            }
            else if (category == "Magic Items")
            {
                FillListBox<IMagic>();
            }
            else if (category == "Holy Items")
            {
                FillListBox<IHoly>();
            }
            else
            {
                FillListBox<IUnholy>();
            }

            if(lstDisplay.Items.Count > index)
            {
                lstDisplay.SelectedIndex = index;
            }
            else
            {
                lstDisplay.SelectedIndex = 0;
            }
        }

        private void btnHoly_Click(object sender, EventArgs e)
        {
            Product p = (Product)lstDisplay.SelectedItem;

            HolyWater? holyWater = inv.Products
                                  .OfType<HolyWater>()
                                  .FirstOrDefault();

            if (p is Weapon wep)
            {
                Weapon item = wep + holyWater;

                if (item != null)
                {
                    BlessItem(item);
                }
            }
            else if (p is Artifact art)
            {
                Artifact item = art + holyWater;

                if (item != null)
                {
                    BlessItem(item);
                }
            }


            RefreshListBox();
        }

        private void BlessItem(Product item)
        {
            DialogResult check = MessageBox.Show("Are you sure you want to apply Holy Water to this Item?\n"
                                                + "This will consume one Holy Water and create a new item.", "Bless item", MessageBoxButtons.YesNo);

            if (check == DialogResult.Yes)
            {
                if (item is HolyWeapon holy)
                {
                    HolyWeapon newItem = new HolyWeapon(holy.ProductID + 20, 1, $@"Blessed {holy.Name}",
                                        "Newly Blessed Item!\n" + $"{holy.Description}",
                                        holy.Price * 1.5m, holy.EffectiveAgainst, holy.Material, true, holy.PowerLevel + 1);

                    InsertItem(newItem);
                }
                else if (item is HolyArtifact holyArt)
                {
                    HolyArtifact newItem = new HolyArtifact(holyArt.ProductID + 110, 1, $@"Blessed {holyArt.Name}",
                                        "Newly Ordained Item!\n" + $"{holyArt.Description}",
                                        holyArt.Price * 1.5m, holyArt.PowerLevel + 1, holyArt.UseCase, holyArt.Vibe, true);

                    InsertItem(newItem);
                }
                else if (item is UnHolyWeapon unholy)
                {
                    UnHolyWeapon newItem = new UnHolyWeapon(unholy.ProductID + 20, 1, $@"Exorcised {unholy.Name}",
                                        "Newly Exorcised Item!\n" + $"{unholy.Description}",
                                        unholy.Price * .5m, unholy.EffectiveAgainst, unholy.Material, false, unholy.PowerLevel - 1);

                    InsertItem(newItem);
                }
                else if (item is UnHolyArtifact unholyArt)
                {
                    UnHolyArtifact newItem = new UnHolyArtifact(unholyArt.ProductID + 110, 1, $@"Exorcised {unholyArt.Name}",
                                        "Newly Exorcised Item!\n" + $"{unholyArt.Description}",
                                        unholyArt.Price * 1.5m, unholyArt.PowerLevel - 1, unholyArt.UseCase, unholyArt.Vibe, false);

                    InsertItem(newItem);
                }
                else if (item is Weapon wep)
                {
                    HolyWeapon newItem = new HolyWeapon(wep.ProductID + 110, 1, $@"Holy {wep.Name}", "Newly Ordained Item!\n" + $"{wep.Description}",
                                        wep.Price * 1.5m, wep.EffectiveAgainst, wep.Material, false, 5);

                    InsertItem(newItem);
                }
                else if (item is Artifact art)
                {
                    HolyArtifact newItem = new HolyArtifact(art.ProductID + 110, 1, $@"Holy {art.Name}",
                                        "Newly Ordained Item!\n" + $"{art.Description}",
                                        art.Price * 1.5m, art.PowerLevel + 1, art.UseCase, art.Vibe, false);

                    InsertItem(newItem);
                }
            }
           
        }

        private void btnBlack_Click(object sender, EventArgs e)
        {
            Product p = (Product)lstDisplay.SelectedItem;

            BlackWater? blackWater = inv.Products
                                  .OfType<BlackWater>()
                                  .FirstOrDefault();

            if (p is Weapon wep)
            {
                Weapon item = wep - blackWater;

                if (item != null)
                {
                    CurseItem(item);
                }
            }
            else if (p is Artifact art)
            {
                Artifact item = art - blackWater;

                if (item != null)
                {
                    CurseItem(item);
                }
            }

            RefreshListBox();

        }

        private void CurseItem(Product item)
        {
            DialogResult check = MessageBox.Show("Are you sure you want to apply Black Water to this Item?\n"
                                                + "This will consume one Black Water and create a new item.", "Curse item", MessageBoxButtons.YesNo);

            if (check == DialogResult.Yes)
            {
                if (item is HolyWeapon holy)
                {
                    HolyWeapon newItem = new HolyWeapon(holy.ProductID + 40, 1, $@"Desecrated {holy.Name}",
                                        "Discount: Recently desecrated\n" + $"{holy.Description}",
                                        holy.Price * .5m, holy.EffectiveAgainst, holy.Material, false, holy.PowerLevel - 1);

                    InsertItem(newItem);
                }
                else if (item is HolyArtifact holyArt)
                {
                    HolyArtifact newItem = new HolyArtifact(holyArt.ProductID + 130, 1, $@"Desecrated {holyArt.Name}",
                                        "Discount: Recently desecrated\n" + $"{holyArt.Description}",
                                        holyArt.Price * .5m, holyArt.PowerLevel - 1, holyArt.UseCase, holyArt.Vibe, false);

                    InsertItem(newItem);
                }
                else if (item is UnHolyWeapon unholy)
                {
                    UnHolyWeapon newItem = new UnHolyWeapon(unholy.ProductID + 40, 1, $@"Cursed {unholy.Name}",
                                        "Discount: Cursed\n" + $"{unholy.Description}",
                                        unholy.Price * .5m, unholy.EffectiveAgainst, unholy.Material, true, unholy.PowerLevel + 1);

                    InsertItem(newItem);
                }
                else if (item is UnHolyArtifact unholyArt)
                {
                    UnHolyArtifact newItem = new UnHolyArtifact(unholyArt.ProductID + 130, 1, $@"Cursed {unholyArt.Name}",
                                        "Discount: Cursed\n" + $"{unholyArt.Description}",
                                        unholyArt.Price * .5m, unholyArt.PowerLevel + 1, unholyArt.UseCase, unholyArt.Vibe, true);

                    InsertItem(newItem);
                }
                else if (item is Weapon wep)
                {
                    UnHolyWeapon newItem = new UnHolyWeapon(wep.ProductID + 130, 1, $@"Desecrated {wep.Name}",
                                        "Discount: Recently desecrated\n" + $"{wep.Description}",
                                        wep.Price * .5m, wep.EffectiveAgainst, wep.Material, false, 5);

                    InsertItem(newItem);
                }
                else if (item is Artifact art)
                {
                    UnHolyArtifact newItem = new UnHolyArtifact(art.ProductID + 130, 1, $@"Desecrated {art.Name}",
                                        "Discount: Recently desecrated!\n" + $"{art.Description}",
                                        art.Price * .5m, art.PowerLevel + 1, art.UseCase, $@"Not as {art.Vibe}", false);

                    InsertItem(newItem);
                }
            }
                
        }

        private void InsertItem(Product item)
        {
            var exists = inv.Products
                          .Where(p => p.Name == item.Name)
                          .FirstOrDefault();

            if (exists == null)
                inv.Products.Add(item);
            else
            {
                exists.Quantity++;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Product p = (Product)lstDisplay.SelectedItem;

            if (p.InStock == true && p != null)
            {
                if(p.Quantity >= nudQuantity.Value)
                {
                    p.Quantity -= Convert.ToInt32(nudQuantity.Value);

                    //Sorcery here to create a deep copy of p without doing all the casting
                    Product cartItem = HelperClasses.DeepCopy(p);

                    cartItem.Quantity = Convert.ToInt32(nudQuantity.Value);

                    inv.Cart.Add(cartItem);
                }
                else
                {
                    MessageBox.Show("Insufficient quantity of stock:\n" + $"Ordered: {nudQuantity.Value}\n" + $"Quantity: {p.Quantity}");
                }
                
            }
            else
            {
                MessageBox.Show("This item is out of stock.");
            }

            RefreshListBox();
        }

        private void btnCart_Click(object sender, EventArgs e)
        {
            CartForm cart = new CartForm(inv);

            cart.ShowDialog();
            //inv.Cart = (List<Product>)cart.Tag;

            RefreshListBox();
        }


    }
}
