﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Project
{
    public partial class CartForm : Form
    {
        public CartForm()
        {
            InitializeComponent();
        }

        Inventory cart = null;

        public CartForm(Inventory inv)
        {
            InitializeComponent();

            cart = inv;

            lstCart.DataSource = null;
            lstCart.DataSource = cart.Cart;
        }

        private void CartForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //this.Tag = cartList;
        }

        private void CartForm_Load(object sender, EventArgs e)
        {
            CheckoutReceipt();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            Product p = (Product)lstCart.SelectedItem;

            if (p != null)
            {
                var item = cart.Products
                        .Where(i => i.Name == p.Name)
                        .FirstOrDefault();

                if (item != null)
                {
                    item.Quantity++;
                    cart.Cart.Remove(p);

                    lstCart.DataSource = null;
                    lstCart.DataSource = cart.Cart;
                }
            }

            CheckoutReceipt();
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            cart.Receipt = CheckoutReceipt();
            checkout form = new checkout(cart);
            form.ShowDialog();
        }

        private string CheckoutReceipt()
        {
            var numItems = cart.Cart
                            .Sum(c => c.Quantity);

            var price = cart.Cart
                            .Sum(c => c.Price * c.Quantity);

            var tax = cart.Cart
                            .Sum(c => c.Price * .15m);

            decimal total = price + tax;

            string receipt =
                $"# of Items: {numItems}\n" +
                $"Price: {price.ToString("c")}\n" +
                $"Tax: {tax.ToString("c")}\n\n" +
                $"Total: {total.ToString("c")}";

            lblTotal.Text = receipt;

            return receipt;
        }

        private void btnClearCart_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("Are you sure you want to clear your Cart? This will remove all items", "Clear Cart", MessageBoxButtons.YesNo);

            if(check == DialogResult.Yes)
            {
                foreach (var item in cart.Cart)
                {
                    var match = cart.Products.FirstOrDefault(p => p.ProductID == item.ProductID);

                    if (match != null)
                    {
                        match.Quantity += item.Quantity;
                    }
                }

                
                cart.Cart.Clear();
                lstCart.DataSource = null;
                lstCart.DataSource = cart.Cart;
                CheckoutReceipt();
            }
            
        }
    }


}
