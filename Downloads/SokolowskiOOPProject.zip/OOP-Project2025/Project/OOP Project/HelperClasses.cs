﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Project
{
    public static class HelperClasses
    {
        //method to create a deep copy of whatever object is getting added to the cart
        //so I don't have to have a giant if else if statement casting between our 11 classes

        //T DeepCopy<T>: Returning type T, where T is passed in
        //(T original): T is the type of the original object passed in
        //where T : Product: Where T is inherited from Product
        public static T DeepCopy<T>(T original) where T : Product
        {
            if (original == null)
            {
                return null;
            }

            //Sorcery, creating an instance of the type of original (presumably accessing RAM memory location)
            T copy = (T)Activator.CreateInstance(original.GetType());

            //gathering the properties of the object into an array
            PropertyInfo[] properties = original.GetType().GetProperties();

            //loop through property array, assigning each value to the value of the 'copy' object
            foreach (var property in properties)
            {
                if (property.CanWrite)
                {
                    property.SetValue(copy, property.GetValue(original));
                }
            }

            return copy;
        }
    }

    public static class ExtractProducts
    {
        public static List<Product> FilterItems()
        {
            List<string> stringList = new List<string>();
            List<Product> prod = new List<Product>();

            string path = @"Inventory.txt";
            if (File.Exists(path))
            {
                foreach (string item in File.ReadLines(path))
                {
                    stringList.Add(item);
                }
            
                foreach (string item in stringList)
                {
                    string[] itemSpecs = item.Split("-");
                    string itemType = itemSpecs[0];

                    int productID = Convert.ToInt32(itemSpecs[1]);
                    int quantity = Convert.ToInt32(itemSpecs[2]);
                    string name = itemSpecs[3];
                    string description = itemSpecs[4];
                    decimal price = Convert.ToDecimal(itemSpecs[5]);

                    if (itemType == "Weapon")
                    {
                        string effective = itemSpecs[6];
                        string material = itemSpecs[7];

                        Product p = new Weapon(productID, quantity, name, description, price, effective, material);
                        prod.Add(p);
                    }
                    else if (itemType == "HolyWeapon")
                    {
                        string effective = itemSpecs[6];
                        string material = itemSpecs[7];
                        bool blessed = Convert.ToBoolean(itemSpecs[8]);
                        int powerLevel = Convert.ToInt32(itemSpecs[9]);

                        Product p = new HolyWeapon(productID, quantity, name, description, price, effective, material, blessed, powerLevel);

                        prod.Add(p);
                    }
                    else if (itemType == "UnHolyWeapon")
                    {
                        string effective = itemSpecs[6];
                        string material = itemSpecs[7];
                        bool cursed = Convert.ToBoolean(itemSpecs[8]);
                        int powerLevel = Convert.ToInt32(itemSpecs[9]);

                        Product p = new UnHolyWeapon(productID, quantity, name, description, price, effective, material, cursed, powerLevel);

                        prod.Add(p);
                    }
                    else if (itemType == "Book")
                    {
                        string subject = itemSpecs[6];
                        int pages = Convert.ToInt32(itemSpecs[7]);

                        Product p = new Book(productID, quantity, name, description, price, subject, pages);

                        prod.Add(p);
                    }
                    else if (itemType == "SpellBook")
                    {
                        string subject = itemSpecs[6];
                        int pages = Convert.ToInt32(itemSpecs[7]);
                        int powerLevel = Convert.ToInt32(itemSpecs[8]);

                        Product p = new SpellBook(productID, quantity, name, description, price, subject, pages, powerLevel);

                        prod.Add(p);
                    }
                    else if (itemType == "Artifact")
                    {
                        int powerLevel = Convert.ToInt32(itemSpecs[6]);
                        string useCase = itemSpecs[7];
                        string vibe = itemSpecs[8];

                        Product p = new Artifact(productID, quantity, name, description, price, powerLevel, useCase, vibe);

                        prod.Add(p);
                    }
                    else if (itemType == "HolyArtifact")
                    {
                        int powerLevel = Convert.ToInt32(itemSpecs[6]);
                        string useCase = itemSpecs[7];
                        string vibe = itemSpecs[8];
                        bool blessed = Convert.ToBoolean(itemSpecs[9]);

                        Product p = new HolyArtifact(productID, quantity, name, description, price, powerLevel, useCase, vibe, blessed);

                        prod.Add(p);
                    }
                    else if (itemType == "UnHolyArtifact")
                    {
                        int powerLevel = Convert.ToInt32(itemSpecs[6]);
                        string useCase = itemSpecs[7];
                        string vibe = itemSpecs[8];
                        bool cursed = Convert.ToBoolean(itemSpecs[9]);

                        Product p = new UnHolyArtifact(productID, quantity, name, description, price, powerLevel, useCase, vibe, cursed);

                        prod.Add(p);
                    }
                    else if (itemType == "Ingredient")
                    {
                        string application = itemSpecs[6];
                        string warnings = itemSpecs[7];

                        Product p = new Ingredient(productID, quantity, name, description, price, application, warnings);

                        prod.Add(p);
                    }
                    else if (itemType == "HolyWater")
                    {
                        string application = itemSpecs[6];
                        string warnings = itemSpecs[7];
                        bool blessed = Convert.ToBoolean(itemSpecs[8]);
                        int powerLevel = Convert.ToInt32(itemSpecs[9]);

                        Product p = new HolyWater(productID, quantity, name, description, price, application, warnings, blessed, powerLevel);

                        prod.Add(p);
                    }
                    else if (itemType == "BlackWater")
                    {
                        string application = itemSpecs[6];
                        string warnings = itemSpecs[7];
                        bool cursed = Convert.ToBoolean(itemSpecs[8]);
                        int powerLevel = Convert.ToInt32(itemSpecs[9]);

                        Product p = new BlackWater(productID, quantity, name, description, price, application, warnings, cursed, powerLevel);

                        prod.Add(p);
                    }
                    else
                    {
                        MessageBox.Show("Error Loading File");
                    }
                }

                return prod;
            }
            else
            {
                MessageBox.Show("Inventory File not found");
                return prod;
            }
        }
    }


}
   
