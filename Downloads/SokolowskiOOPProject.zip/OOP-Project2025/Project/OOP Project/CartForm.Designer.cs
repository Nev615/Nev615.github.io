﻿namespace OOP_Project
{
    partial class CartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstCart = new ListBox();
            btnRemove = new Button();
            btnCheckout = new Button();
            label1 = new Label();
            lblTotal = new Label();
            pictureBox1 = new PictureBox();
            btnClearCart = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lstCart
            // 
            lstCart.FormattingEnabled = true;
            lstCart.Location = new Point(269, 40);
            lstCart.Name = "lstCart";
            lstCart.Size = new Size(337, 251);
            lstCart.TabIndex = 0;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(639, 161);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(124, 62);
            btnRemove.TabIndex = 1;
            btnRemove.Text = "Remove Item";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnCheckout
            // 
            btnCheckout.Location = new Point(639, 229);
            btnCheckout.Name = "btnCheckout";
            btnCheckout.Size = new Size(124, 62);
            btnCheckout.TabIndex = 2;
            btnCheckout.Text = "Checkout";
            btnCheckout.UseVisualStyleBackColor = true;
            btnCheckout.Click += btnCheckout_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(269, 12);
            label1.Name = "label1";
            label1.Size = new Size(39, 19);
            label1.TabIndex = 3;
            label1.Text = "Cart:";
            // 
            // lblTotal
            // 
            lblTotal.BorderStyle = BorderStyle.FixedSingle;
            lblTotal.Location = new Point(12, 40);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(251, 251);
            lblTotal.TabIndex = 4;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.image;
            pictureBox1.Location = new Point(696, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(67, 62);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // btnClearCart
            // 
            btnClearCart.Location = new Point(639, 93);
            btnClearCart.Name = "btnClearCart";
            btnClearCart.Size = new Size(124, 62);
            btnClearCart.TabIndex = 11;
            btnClearCart.Text = "Clear Cart";
            btnClearCart.UseVisualStyleBackColor = true;
            btnClearCart.Click += btnClearCart_Click;
            // 
            // CartForm
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(772, 308);
            Controls.Add(btnClearCart);
            Controls.Add(pictureBox1);
            Controls.Add(lblTotal);
            Controls.Add(label1);
            Controls.Add(btnCheckout);
            Controls.Add(btnRemove);
            Controls.Add(lstCart);
            Font = new Font("Tempus Sans ITC", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "CartForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Albert, Sadia, Nev";
            FormClosing += CartForm_FormClosing;
            Load += CartForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox lstCart;
        private Button btnRemove;
        private Button btnCheckout;
        private Label label1;
        private Label lblTotal;
        private PictureBox pictureBox1;
        private Button btnClearCart;
    }
}